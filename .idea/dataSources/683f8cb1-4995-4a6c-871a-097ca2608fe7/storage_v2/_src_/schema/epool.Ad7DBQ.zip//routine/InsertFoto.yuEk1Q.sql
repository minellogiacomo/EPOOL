create
    definer = root@localhost procedure InsertFoto(IN Emailt varchar(30), IN Path varchar(100), OUT result tinyint(1))
BEGIN

            START TRANSACTION;
            SET result = (FALSE);
            INSERT INTO Foto (`EMAIL_UTENTE`,`PATHFOTO`)  VALUES(Emailt, Path);
            COMMIT WORK;
            SET result = (TRUE);

END;


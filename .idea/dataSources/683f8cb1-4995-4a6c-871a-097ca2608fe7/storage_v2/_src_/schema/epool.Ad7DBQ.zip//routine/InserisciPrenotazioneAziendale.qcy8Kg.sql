create
    definer = root@localhost procedure InserisciPrenotazioneAziendale(IN Tragitto smallint(6), IN Notet varchar(300),
                                                                      IN Automobile varchar(10), IN Emailt varchar(30),
                                                                      IN IndirizzoPartenzat varchar(30),
                                                                      IN IndirizzoArrivot varchar(30),
                                                                      OUT result tinyint(1))
BEGIN
    start transaction;
    SET result = (FALSE);
    INSERT INTO `prenotazione` ( `NOTE`, `AUTO`, `UTENTE`, `INDIRIZZO_PARTENZA`, `INDIRIZZO_ARRIVO`) VALUES ( Notet, Automobile, Emailt, IndirizzoPartenzat, IndirizzoArrivot);
    SET result =  (SELECT LAST_INSERT_ID());
    INSERT INTO `tragitto_prenotazione` ( `ID_TRAG`, `ID_PREN`) VALUES ( Tragitto, result);
    SET result = (TRUE);
    commit work;
END;


create definer = root@localhost view veicoli_disponibili as
select `epool`.`veicolo`.`TARGA`       AS `TARGA`,
       `epool`.`veicolo`.`MODELLO`     AS `MODELLO`,
       `epool`.`veicolo`.`CAPIENZA`    AS `CAPIENZA`,
       `epool`.`veicolo`.`DESCRIZIONE` AS `DESCRIZIONE`,
       `epool`.`veicolo`.`FERIALE`     AS `FERIALE`,
       `epool`.`veicolo`.`FESTIVO`     AS `FESTIVO`,
       `epool`.`veicolo`.`SOCIETA`     AS `SOCIETA`,
       `epool`.`veicolo`.`AREA_SOSTA`  AS `AREA_SOSTA`
from `epool`.`veicolo`
where (`epool`.`veicolo`.`STATO` = 'NON IN USO');


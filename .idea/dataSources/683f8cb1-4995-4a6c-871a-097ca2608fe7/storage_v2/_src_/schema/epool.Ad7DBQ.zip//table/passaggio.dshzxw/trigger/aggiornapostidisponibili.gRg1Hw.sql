create definer = root@localhost trigger AggiornaPostiDisponibili
    after INSERT
    on passaggio
    for each row
BEGIN
    UPDATE TAPPA
        SET TAPPA.POSTI=TAPPA.POSTI-1
        WHERE TAPPA.VIA=new.INDIRIZZO_ARRIVO and 
              tappa.ID_TRAGITTO=new.ID_TAPPA
              ;
END;


create
    definer = root@localhost procedure InserisciValutazione(IN Emailt varchar(30), IN TestoValutazione varchar(500),
                                                            IN VotoValutazione smallint(6), IN UtenteV varchar(30),
                                                            OUT result tinyint(1))
BEGIN
    start transaction;
    SET result = (FALSE);
    INSERT INTO `valutazione` (`EMAIL`, `DATA`, `TESTO`, `VOTO` , `UTENTE`) VALUES (Emailt, CURRENT_DATE, TestoValutazione, VotoValutazione, UtenteV);
    SET result = (TRUE);
    commit work;
END;


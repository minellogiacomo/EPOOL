create definer = root@localhost view prenotazione_capienza as
select distinct `epool`.`veicolo`.`TARGA`          AS `AUTO`,
                (`epool`.`veicolo`.`CAPIENZA` - 1) AS `POSTI_DISPONIBILI`,
                `epool`.`tragitto`.`ID`            AS `IDTRAGITTO`,
                `epool`.`prenotazione`.`UTENTE`    AS `GUIDATORE`,
                `epool`.`tappa`.`CITTA`            AS `TAPPA_CITTA`,
                `epool`.`tappa`.`VIA`              AS `TAPPA_VIA`
from `epool`.`prenotazione`
         join `epool`.`veicolo`
         join `epool`.`tragitto_prenotazione`
         join `epool`.`tragitto`
         join `epool`.`tappa`
where ((`epool`.`prenotazione`.`AUTO` = `epool`.`veicolo`.`TARGA`) and
       (`epool`.`prenotazione`.`ID` = `epool`.`tragitto_prenotazione`.`ID_PREN`) and
       (`epool`.`tragitto`.`ID` = `epool`.`tragitto_prenotazione`.`ID_TRAG`) and
       (`epool`.`tappa`.`ID_TRAGITTO` = `epool`.`tragitto`.`ID`));


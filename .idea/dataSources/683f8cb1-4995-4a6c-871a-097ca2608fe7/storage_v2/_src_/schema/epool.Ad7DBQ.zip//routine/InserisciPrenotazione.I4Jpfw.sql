create
    definer = root@localhost procedure InserisciPrenotazione(IN Notet varchar(300), IN Automobile varchar(10),
                                                             IN Emailt varchar(30), IN IndirizzoPartenzat varchar(30),
                                                             IN IndirizzoArrivot varchar(30), OUT result tinyint(1))
BEGIN
    start transaction;
    SET result = (FALSE);
    INSERT INTO `prenotazione` ( `NOTE`, `AUTO`, `UTENTE`, `INDIRIZZO_PARTENZA`, `INDIRIZZO_ARRIVO`) VALUES ( Notet, Automobile, Emailt, IndirizzoPartenzat, IndirizzoArrivot);
    SET result = (TRUE);
    commit work;
END;


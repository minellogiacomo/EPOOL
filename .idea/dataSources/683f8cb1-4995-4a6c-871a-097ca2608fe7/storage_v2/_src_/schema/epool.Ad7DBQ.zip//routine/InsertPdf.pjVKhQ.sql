create
    definer = root@localhost procedure InsertPdf(IN Nome varchar(30), IN Pathpdf varchar(100), OUT result tinyint(1))
BEGIN

    START TRANSACTION;
    SET result = (FALSE);
    INSERT INTO PDF (`NOME_SOCIETA`,`PATH`)  VALUES(Nome, Pathpdf);
    COMMIT WORK;
    SET result = (TRUE);

END;


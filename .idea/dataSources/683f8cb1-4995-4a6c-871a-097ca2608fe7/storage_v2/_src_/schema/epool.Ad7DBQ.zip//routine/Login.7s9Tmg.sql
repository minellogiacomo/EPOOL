create
    definer = root@localhost procedure Login(IN Email varchar(30), IN pasw varchar(30), OUT result tinyint(1))
BEGIN DECLARE statoUtente int;IF EXISTS(
  SELECT
    *
  FROM
    UTENTE
  WHERE
    UTENTE.EMAIL = Email
    AND UTENTE.PW = pasw
) THEN
SET
  result = (TRUE);
  ELSE
SET
  result = (FALSE);END IF;
  END;


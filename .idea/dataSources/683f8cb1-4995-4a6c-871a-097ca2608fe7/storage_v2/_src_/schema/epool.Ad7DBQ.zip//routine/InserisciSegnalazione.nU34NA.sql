create
    definer = root@localhost procedure InserisciSegnalazione(IN Emailt varchar(30), IN SocietaAutomobile varchar(30),
                                                             IN DataSegnalazione date,
                                                             IN TitoloSegnalazione varchar(20),
                                                             IN TestoSegnalazione varchar(200),
                                                             IN Automobile varchar(10), OUT result tinyint(1))
BEGIN
    start transaction;
    SET result = (FALSE);
    INSERT INTO `segnalazione` (`EMAIL`, `SOCIETA`, `DATA`, `TITOLO`, `TESTO`, `AUTO`) VALUES (Emailt, SocietaAutomobile, DataSegnalazione, TitoloSegnalazione, TestoSegnalazione, Automobile);
    SET result = (TRUE);
    commit work;
END;


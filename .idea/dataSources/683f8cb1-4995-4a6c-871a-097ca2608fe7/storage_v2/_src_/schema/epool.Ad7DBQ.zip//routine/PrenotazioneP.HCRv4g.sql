create
    definer = root@localhost procedure PrenotazioneP(IN NoteQ varchar(300), IN AutoQ varchar(10),
                                                     IN UtenteQ varchar(30), IN Partenza varchar(30),
                                                     IN Arrivo varchar(30), OUT result tinyint(1))
BEGIN
    start transaction;
    SET result = (FALSE);
	INSERT INTO PRENOTAZIONE (NOTE, AUTO, UTENTE, INDIRIZZO_PARTENZA, INDIRIZZO_ARRIVO)
	VALUES ( NoteQ, AutoQ, UtenteQ, Partenza, Arrivo);
	commit work;
	SET result = (TRUE);
END;


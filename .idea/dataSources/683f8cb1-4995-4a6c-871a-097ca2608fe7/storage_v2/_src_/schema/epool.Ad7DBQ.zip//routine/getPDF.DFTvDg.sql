create
    definer = root@localhost procedure getPDF(IN Nome varchar(30))
BEGIN
    SELECT * FROM PDF WHERE Nome=PDF.NOME_SOCIETA;
END;


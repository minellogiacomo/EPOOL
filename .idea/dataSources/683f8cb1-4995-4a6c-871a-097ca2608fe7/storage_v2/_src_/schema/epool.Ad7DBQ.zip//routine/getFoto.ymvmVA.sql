create
    definer = root@localhost procedure getFoto(IN Emailt varchar(30))
BEGIN
    SELECT * FROM FOTO WHERE Emailt=FOTO.EMAIL_UTENTE;
END;


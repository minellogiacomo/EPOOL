create definer = root@localhost view media_voto_utente as
select `epool`.`valutazione`.`UTENTE` AS `UTENTE`, avg(`epool`.`valutazione`.`VOTO`) AS `MEDIA_VOTO`
from `epool`.`valutazione`
group by `epool`.`valutazione`.`UTENTE`
order by avg(`epool`.`valutazione`.`VOTO`) desc;


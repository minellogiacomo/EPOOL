create
    definer = root@localhost procedure printf(IN mytext text)
BEGIN

  select mytext as ``;

END;

